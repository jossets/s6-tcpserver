cp s6-tcpserver   /bin/
chmod a+x /bin/s6-tcpserver

cp s6-tcpserver-socketbinder /bin/
chmod a+x s6-tcpserver-socketbinder

cp s6-tcpserverd /bin/
chmod a+x s6-tcpserverd

cp libskarnet.so.2.14 /lib/
chmod a+rx /lib/libskarnet.so.2.14