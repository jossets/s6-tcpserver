/* ISC license. */

#include <skalibs/cdb.h>

#include <s6-dns/hosts.h>

cdb s6dns_hosts_here = CDB_ZERO ;
