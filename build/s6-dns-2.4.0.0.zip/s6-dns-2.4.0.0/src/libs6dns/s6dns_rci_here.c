/* ISC license. */

#include <s6-dns/s6dns-rci.h>

s6dns_rci_t s6dns_rci_here = S6DNS_RCI_ZERO ;
