/* ISC license. */

#include <s6-dns/s6dns-message.h>

s6dns_message_header_t const s6dns_message_header_zero = S6DNS_MESSAGE_HEADER_ZERO ;
