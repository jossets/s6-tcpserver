/* ISC license. */

#ifndef S6LOCKD_H
#define S6LOCKD_H

extern int s6lockd_openandlock (char const *, int, int) ;

#endif
