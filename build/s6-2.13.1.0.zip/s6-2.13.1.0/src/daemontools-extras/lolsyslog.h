/* ISC license. */

#ifndef LOLSYSLOG_H
#define LOLSYSLOG_H

#define LOLSYSLOG_STRING 32

extern size_t lolsyslog_string (char *, char const *) ;

#endif
