/* ISC license. */

#ifndef CSPAWN_INTERNAL_H
#define CSPAWN_INTERNAL_H

#include <sys/types.h>

extern pid_t child_spawn1_internal (char const *, char const *const *, char const *const *, int *, int) ;

#endif
