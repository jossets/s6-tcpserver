/* ISC license. */

#include <skalibs/genalloc.h>
#include <skalibs/envalloc.h>

int envalloc_0 (genalloc *v)
{
  char const *z = 0 ;
  return genalloc_append(char const *, v, &z) ;
}
