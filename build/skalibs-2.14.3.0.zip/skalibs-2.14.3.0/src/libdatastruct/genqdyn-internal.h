/* ISC license. */

#ifndef SKALIBS_GENQDYN_INTERNAL_H
#define SKALIBS_GENQDYN_INTERNAL_H

#include <skalibs/genqdyn.h>

extern void genqdyn_clean (genqdyn *) ;

#endif
