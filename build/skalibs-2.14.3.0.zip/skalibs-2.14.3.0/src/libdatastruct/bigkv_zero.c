/* ISC license. */

#include <skalibs/bigkv.h>

bigkv const bigkv_zero = BIGKV_ZERO ;
