/* ISC license. */

#ifndef SKALIBS_DATASTRUCT_H
#define SKALIBS_DATASTRUCT_H

#include <skalibs/genqdyn.h>
#include <skalibs/genset.h>
#include <skalibs/gensetdyn.h>
#include <skalibs/avlnode.h>
#include <skalibs/avltree.h>
#include <skalibs/avltreen.h>
#include <skalibs/bigkv.h>

#endif
