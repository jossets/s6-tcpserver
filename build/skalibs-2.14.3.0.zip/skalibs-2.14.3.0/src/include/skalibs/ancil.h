/* ISC license. */

#ifndef SKALIBS_ANCIL_H
#define SKALIBS_ANCIL_H

extern int ancil_recv_fd (int, char) ;
extern int ancil_send_fd (int, int, char) ;

#endif
