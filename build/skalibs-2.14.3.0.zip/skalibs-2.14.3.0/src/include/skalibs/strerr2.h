/* ISC license. */

#ifndef SKALIBS_STRERR2_H
#define SKALIBS_STRERR2_H

#include <skalibs/strerr.h>

#warning strerr2.h is now deprecated, use #include <skalibs/strerr.h> instead.

#endif
