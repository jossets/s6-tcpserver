/* ISC license. */

#include "fmtscan-internal.h"
#include <skalibs/uint32.h>

FMTSL(32)
