/* ISC license. */

#include "fmtscan-internal.h"
#include <skalibs/uint64.h>

SCANSL(64)
