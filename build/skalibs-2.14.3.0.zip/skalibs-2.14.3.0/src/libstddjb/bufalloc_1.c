/* ISC license. */

/* MT-unsafe */

#include <skalibs/allreadwrite.h>
#include <skalibs/bufalloc.h>

bufalloc bufalloc_1_ = BUFALLOC_INIT(&fd_write, 1) ;
