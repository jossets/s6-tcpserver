/* ISC license. */

#ifndef ALARM_INTERNAL_H
#define ALARM_INTERNAL_H

#ifdef SKALIBS_HASTIMER

#include <time.h>

extern timer_t timer_here ;

#endif

#endif
