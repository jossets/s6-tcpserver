/* ISC license. */

#include "fmtscan-internal.h"
#include <skalibs/uint16.h>

SCANSL(16)
