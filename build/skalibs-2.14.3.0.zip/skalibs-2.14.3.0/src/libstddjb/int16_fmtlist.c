/* ISC license. */

#include "fmtscan-internal.h"
#include <skalibs/uint16.h>

FMTSL(16)
